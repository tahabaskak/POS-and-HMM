
public class TransitionAndEmission {
	private String word;
	private String tag;
	private int tagCount;
	private int allTagCount;
	private int wordTagCount;
	public int getAllTagCount() {
		return allTagCount;
	}
	public void setAllTagCount(int allTagCount) {
		this.allTagCount = allTagCount;
	}
	public int getWordTagCount() {
		return wordTagCount;
	}
	public void setWordTagCount(int wordTagCount) {
		this.wordTagCount = wordTagCount;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public int getTagCount() {
		return tagCount;
	}
	public void setTagCount(int tagCount) {
		this.tagCount = tagCount;
	}
}
