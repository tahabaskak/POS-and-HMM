import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import javax.jws.Oneway;

public class Main {

	public static void main(String[] args) {
		BufferedWriter output = null;
		BufferedWriter output2 = null;
		try {
            File file = new File("output_tokens.txt");
            output = new BufferedWriter(new FileWriter(file));
            File file2 = new File("output_set.txt");
            output2 = new BufferedWriter(new FileWriter(file2));
            ArrayList<Words> allWords = new ArrayList<Words>();										/* All Word stored*/
    		ArrayList<Words> tagProbabilities = new ArrayList<Words>();								/* initial tag probabilities */
    		ArrayList<String> inputWords = new ArrayList<String>();									/* for input_token.txt  */
    		ArrayList<String> inputWords2 = new ArrayList<String>();								/* for test_set.txt */
    		ArrayList<TransitionAndEmission> tAndEPros = new ArrayList<TransitionAndEmission>();	/* for task four */
    		ArrayList<emissionPro> emissionPros = new ArrayList<emissionPro>();						/* for task three */
    		fileFounder("brown",allWords);	/* read file for brown corpus */
    		readFileForText("input_tokens.txt",inputWords);	/* read file input_token.txt */
    		readFileForText("test_set.txt",inputWords2);		/* read file test_set.txt */
    		
    		initialTagProbabilities(allWords, tagProbabilities);	/* go function and start word */
    		forTaskThree(allWords, inputWords, emissionPros,tagProbabilities);	/* create a arraylist for emission probability */
    		addingTagWords(emissionPros, inputWords,tagProbabilities,output);	/* Adding tag for every word */
    		
    		forTaskThree(allWords, inputWords2, emissionPros,tagProbabilities);	/* create a arraylist for emission probability */
    		forTaskFour(emissionPros, inputWords2, allWords,tAndEPros,tagProbabilities);	/* Tags  and  word condition calculated */
    		addingTagWordsWithViterbi(tAndEPros, inputWords2,tagProbabilities,output2); /* Adding tag for every word with viterbi algorithm*/
    		
        } catch ( IOException e ) {
            e.printStackTrace();
        } finally {								/* Opened output file finished closed. */
          if ( output != null ) {
			try {
				output.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
          } 
          if ( output2 != null ) {
			  try {
				output2.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			   }
        }	
	}
	
	public static void addingTagWordsWithViterbi(ArrayList<TransitionAndEmission> tAndEPros,ArrayList<String> inputWords,ArrayList<Words> tagProbabilities, BufferedWriter output2) throws IOException{
		int max = Integer.MIN_VALUE;	/* for finding max tag count */
		double maxTagCondition = Integer.MIN_VALUE;	/* for sum tags count */
		int index = 0;				/* Find element index in ArrayList */
		String sentence=null;		/* create sentence for print */
		for(String s: inputWords){
			for(int i=0;i<tAndEPros.size();i++){
				if(s.equals(tAndEPros.get(i).getWord())){		
					if((int)tAndEPros.get(i).getTagCount() > max){	/* Finding max tag and index for every word of test_set */
						max = (int)tAndEPros.get(i).getTagCount();
						index = i;
						maxTagCondition= Math.log10((double)tAndEPros.get(i).getTagCount()/(double)tAndEPros.get(i).getAllTagCount());
					}
				}
			}
			if(s.equals(".")){	/* If word is . , so sentence finish and print */
				sentence += s + "/" + tAndEPros.get(index).getTag() +" ";
				output2.write(sentence);
				output2.write("\r\n");
				sentence = null;	/* After sentence free */
			}
			else{
				if(sentence == null){	/* Sentence is null , so first word and tag adding */
					sentence = s + "/" + tAndEPros.get(index).getTag() +" ";
				}
				else{					/* Sentence is not null , so new word and tag adding  */
					sentence += s + "/" + tAndEPros.get(index).getTag() +" ";
				}
			}
			max=Integer.MIN_VALUE;	/* max number and index set for new word  */
			index =0;
		}
	}
	
	public static void forTaskFour(ArrayList<emissionPro> emissionPros,ArrayList<String> inputWords,ArrayList<Words> allWords,ArrayList<TransitionAndEmission> tAndEPros,ArrayList<Words> tagProbabilities){
		TransitionAndEmission newPro;
		int tagCounter = 0;
		ArrayList<String> inputTags = new ArrayList<String>();
		for(String s:inputWords){	/*  find tags for inputWords	*/
			for(emissionPro w:emissionPros){
				if(s.equals(w.getWord())){
					if(!inputTags.contains(w.getTag())){
						inputTags.add(w.getTag());	/* find and save different tag */
					}
				}	
			}
			for(String t:inputTags){	/* Calculate tags count for every word */
				tagCounter += tagCount(t, allWords);
			}
			for(String t:inputTags){
				if(!t.equals("")){
					if(tAndEPros.isEmpty()){		/* if tAndEPros is free, so first element setting and adding */
						newPro = new TransitionAndEmission();
						int wordWithTagCount = wordWithTag(t, s, allWords);		/* Count word and tag together  */
						if(wordWithTagCount != 0){		/* if word and tag count is not zero adding */
							int tagCount = tagCount(t, allWords);				/* Count tag for Every tag inputTags */
							newPro.setTag(t);
							newPro.setWord(s);
							newPro.setWordTagCount(wordWithTagCount);
							newPro.setTagCount(tagCount);
							newPro.setAllTagCount(tagCounter);
							tAndEPros.add(newPro);
						}
					}
					else{						/* if tAndEPros is not free, so new element setting and adding */
						newPro = new TransitionAndEmission();
						int wordWithTagCount = wordWithTag(t, s, allWords);		/* Count word and tag together  */
						if(wordWithTagCount != 0){			/* if word and tag count is not zero adding */
							int tagCount = tagCount(t, allWords);				/* Count tag for Every tag inputTags */
							newPro.setTag(t);
							newPro.setWord(s);
							newPro.setWordTagCount(wordWithTagCount);
							newPro.setTagCount(tagCount);
							newPro.setAllTagCount(tagCounter);
							if(!tAndEPros.contains(newPro))		/* if newPro adding previously , does not adding */
								tAndEPros.add(newPro);
						}
					}
				}
			}
			inputTags.clear();		/* inputTags free for every word */
		}
	}
	
	public static void addingTagWords(ArrayList<emissionPro> emissionPros,ArrayList<String> inputWords,ArrayList<Words> tagProbabilities,BufferedWriter output) throws IOException{
		int max = Integer.MIN_VALUE;		/* for finding max tag count */
		int index = 0;					/* Find element index in ArrayList */
		String sentence=null;			/* create sentence for print */
		for(String s: inputWords){
			for(int i=0;i<emissionPros.size();i++){
				if(s.equals(emissionPros.get(i).getWord())){
					if((int)emissionPros.get(i).getTagCount() > max){	/* Finding max tag and index for every word of test_set */
						max = (int)emissionPros.get(i).getTagCount();
						index = i;
					}
				}
			}
			if(s.equals(".")){			/* If word is . , so sentence finish and print */
				sentence += s + "/" + emissionPros.get(index).getTag() +"\n";
				output.write(sentence);
				output.write("\r\n");
				sentence = null;		/* After sentence free */
			}
			else{
				if(sentence == null){		/* Sentence is null , so first word and tag adding */
					sentence = s + "/" + emissionPros.get(index).getTag() +" ";
				}
				else{					/* Sentence is not null , so new word and tag adding  */
					sentence += s + "/" + emissionPros.get(index).getTag() +" ";
				}
			}
			max=Integer.MIN_VALUE;		/* max number and index set for new word  */
			index =0;
		}
	}

	public static void forTaskThree (ArrayList<Words> allWords,ArrayList<String> inputWords,ArrayList<emissionPro> emissionPros,ArrayList<Words> tagProbabilities){
		emissionPro newPro;
		ArrayList<String> inputTags = new ArrayList<String>();
		for(String s:inputWords){			/*  find tags for inputWords	*/
			for(Words w:allWords){
				if(s.equals(w.getWord())){
					if(!inputTags.contains(w.getTag())){		/* find and save different tag */
						inputTags.add(w.getTag());
					}
				}	
			}
			for(String t:inputTags){
				if(!t.equals("")){	
					if(emissionPros.isEmpty()){		/* if tAndEPros is free, so first element setting and adding */
						newPro = new emissionPro();
						int wordWithTagCount = wordWithTag(t, s, allWords);			/* Count word and tag together  */
						if(wordWithTagCount!=0){		/* if word and tag count is not zero adding */
							int tagCount = tagCount(t, allWords);			/* Count tag for Every tag inputTags */
							newPro.setWord(s);
							newPro.setTag(t);
							newPro.setWordTagCount(wordWithTagCount);
							newPro.setTagCount(tagCount);
							emissionPros.add(newPro);
						}
					}
					else{							/* if tAndEPros is not free, so new element setting and adding */
						newPro = new emissionPro();	
						int wordWithTagCount = wordWithTag(t, s, allWords);			/* Count word and tag together  */
						if(wordWithTagCount!=0){		/* if word and tag count is not zero adding */
							int tagCount = tagCount(t, allWords);			/* Count tag for Every tag inputTags */
							newPro.setWord(s);
							newPro.setTag(t);
							newPro.setWordTagCount(wordWithTagCount);
							newPro.setTagCount(tagCount);
							if(!emissionPros.contains(newPro))			/* if newPro adding previously , does not adding */
								emissionPros.add(newPro);
						}
					}
				}
			}
			inputTags.clear();				/* inputTags free for every word */
		}
	}

	public static int wordWithTag(String tag, String word , ArrayList<Words> allWords){
		int count = 0;				
		for(Words w : allWords){
			if(w.getWord().contains(word) && w.getTag().contains(tag))		/* Counter word and tag with together */
				count++;
		}
		return count;
	}
		
	public static int tagCount(String tag ,ArrayList<Words> allWords){
		int countTag = 0;
		for(Words w : allWords){
			if(w.getTag().contains(tag))	/* Counter tag in all word */
				countTag++;
		}
		return countTag;
	}
	
	public static int twoTagCount(String tagOne, String tagTwo , ArrayList<Words> allWords){
		int countTag = 0;
		for(int i = 0 ; i<allWords.size() ; i++){
			if(i+1<allWords.size()){				/* Counter consecutive tag */
				if(allWords.get(i).getWord().equals(tagOne) && allWords.get(i+1).getWord().equals(tagTwo)){
					countTag++;
				}
			}
		}
		return countTag;
	}
	
	public static void initialTagProbabilities(ArrayList<Words> allWords,ArrayList<Words> tagProbabilities){
		Words newWord;
		for(int i = 0 ; i<allWords.size() ; i++){
			if(i==0){			/* if first element come, adding initial Tag */
				newWord = new Words();
				newWord.setWord(allWords.get(i).getWord());
				newWord.setTag(allWords.get(i).getTag());
				tagProbabilities.add(newWord);
			}
			else{
				if(!allWords.get(i).getWord().isEmpty())		/* if adding tag previously in tagPro, adding new element */
					if(Character.isUpperCase(allWords.get(i).getWord().codePointAt(0)) && 	/*if first character Upper case */
											(allWords.get(i-1).getTag().equals(".") ||		/*if previously word is dot */
											 allWords.get(i-1).getTag().equals(":"))){		/*if previously word is : */
						newWord = new Words();
						newWord.setWord(allWords.get(i).getWord());
						newWord.setTag(allWords.get(i).getTag());
						tagProbabilities.add(newWord);		/* Adding initial tag */
					}
			}
		}
	}
	
	public static void fileFounder(String path,ArrayList<Words> allWords){
		File paths = new File(path);			/* File paths for all words in Brown corpus */
		File[] pathList = paths.listFiles();
		
		if(pathList == null){
			return;
		}
		for(File f : pathList){
			if(f.isDirectory()){				/* if paths is a directory,try again function */
				fileFounder(f.getAbsolutePath(),allWords);
			}
			else{
				if(!f.getAbsolutePath().contains(".DS"))	/* if file name not incude .DS */
					readFile(f.getAbsolutePath(),allWords);		/* Go read file function for read file */
			}
		}
	}
	
	public static void readFileForText (String fileName,ArrayList<String> inputWords){
		try{
			FileReader inputFile = new FileReader(fileName);			/* Opening file */
			BufferedReader  bufferReader = new BufferedReader(inputFile);
			String line;
			while((line = bufferReader.readLine()) != null){		/* read line by line */
				if(!line.isEmpty())									/* if line is not empty , continue */
					splitingForText(line, inputWords);				/* go splitForText function for spliting */
			}
			bufferReader.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void splitingForText(String line,ArrayList<String> inputWords){
		
		String[] splitString = line.trim().split("[\\\t\\ \\\n]");		/* splitting for tab space , space , new line */
		for(int i=0; i<splitString.length ; i++){
			if(!splitString[i].isEmpty() && splitString[i].contains("")){
				inputWords.add(splitString[i]);							/* Adding input Word */
			}	
		}
	}
	
	public static void readFile (String fileName,ArrayList<Words> allWords){
		try{
			FileReader inputFile = new FileReader(fileName);				/* Opening file */
			BufferedReader  bufferReader = new BufferedReader(inputFile);
			String line;	
			while((line = bufferReader.readLine()) != null){				/* read line by line */
				if(!line.isEmpty()){								/* if line is not empty , continue */
					spliting(line, allWords);						/* go splitForText function for spliting */
				}
					
			}
			bufferReader.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void spliting(String line,ArrayList<Words> allWords){
		Words newWord;
		String[] splitString = line.trim().split("[\\\t\\ \\\n]");		/* splitting for tab space , space , new line */
		for(int i=0; i<splitString.length ; i++){
			if(!splitString[i].isEmpty() && splitString[i].contains("")){
				newWord = new Words();
				String[] splitString2 = splitString[i].trim().split("[\\/\\ ]");	/* splitting for "/" */
				newWord.setWord(splitString2[0]);
				newWord.setTag(splitString2[1]);
				allWords.add(newWord);								/* adding word for all words array list */
			}	
		}
	}
		
}
