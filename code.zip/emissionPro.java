
public class emissionPro {
	private String word;
	private String tag;
	private int wordTagCount;
	private int tagCount;
	public int getWordTagCount() {
		return wordTagCount;
	}
	public void setWordTagCount(int wordTagCount) {
		this.wordTagCount = wordTagCount;
	}
	public int getTagCount() {
		return tagCount;
	}
	public void setTagCount(int tagCount) {
		this.tagCount = tagCount;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}

}
